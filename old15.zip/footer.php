
    <section class="footer">
      <div class="container">
        <img src="images/logo3.png" style="width: 20%" />
        <p>Handcrafted Travel Experiences | Personalized Travel Consulting</p>
        <ul>
          <li>
            <a href="https://www.facebook.com/amaaviexperiences/">
              <img src="images/fb.png" class="img-responsive" />
            </a>
          </li>
          <li>
            <a href="https://www.instagram.com/amaaviexperiences/?hl=en">
              <img src="images/instagram.png" class="img-responsive" />
            </a>
          </li>
          <!--<li> <a href="#"> <img src="images/youtube.png" class="img-responsive"> </a> </li>-->
          <li>
            <a href="https://www.linkedin.com/company/amaavi-experiences/about/">
              <img src="images/linkdien.png" class="img-responsive" />
            </a>
          </li>
        </ul>
      </div>
    </section>

    <section class="sub_footer">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <p class="copyrights">Copyright © Amaavi Experiences Pvt. Ltd.2023</p>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 center-block" style="text-align: right">
            <a href="privacy.php" target="_blank" class="privacy" style="color: #ffffff">
              Privacy Policy
            </a>
            <a href="termscondition.php" target="_blank" class="privacy" style="color: #ffffff">
              Terms & Conditions
            </a>
            <a href="refundpolicy.php" target="_blank" class="privacy" style="color: #ffffff">
              Refund Policy
            </a>
          </div>
        </div>
      </div>
    </section>

<div style="position: relative;position: fixed;z-index: 1000;bottom: 50px;left: 30px;">
  <div  style="position:fixed;">
      <form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_MWyuDOiKPamM9c" async> </script> </form>
  </div>
</div>